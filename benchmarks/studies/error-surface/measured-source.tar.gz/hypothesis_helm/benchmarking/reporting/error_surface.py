"""
Plot paired error-rate measurements without extrapolating incomplete runs or zero-error recall.
"""

import csv
import math
import statistics
from pathlib import Path

from hypothesis_helm.benchmarking.reporting.plots import finish
from hypothesis_helm.benchmarking.studies.error_surface import METRICS
from hypothesis_helm.schemas.contracts import mapping, sequence


def plot(output: Path, document: dict[str, object]) -> None:
    """
    Draw comparable method panels and retain means and observed ranges in a summary table.

    Args:
        output (Path): Study artifact destination.
        document (dict[str, object]): Actual measurements, including partial rows and oracle counts.

    Returns:
        None: PNG/SVG heatmaps and CSV summaries accompany a concise study guide.
    """
    import numpy as np
    from matplotlib import pyplot as plt

    metadata = mapping(document["metadata"])
    rows = [mapping(row) for row in sequence(document["rows"])]
    methods = [str(method) for method in sequence(metadata["methods"])]
    rates = [float(str(rate)) for rate in sequence(metadata["error_rates"])]
    labels = {
        "depth": "Nested conditions",
        "redundancy": "Inputs ignored by the rendered output",
        "clustering": "Clustering control (0 = scattered, 1 = grouped)",
    }
    metric_labels = {
        "total_seconds": "Total measured seconds",
        "render_invocations": "Helm renders",
        "error_recall": "Erroneous inputs detected / all erroneous inputs",
        "additional_executed": "Additional inputs checked after failures",
    }
    lines = [
        "# Error rate and filtering",
        "",
        "[Benchmarking](../../README.md)",
        "",
        "Each surface changes error rate and one other parameter. Every method receives the same chart, assertion, and traversal seed.",
        "Errors are seeded, input-aware assertions checked against actual Helm output. Templates stay fixed across error rates and seeds.",
        "A failing assignment expects a corrected quantile value. This measures semantic property failures, not YAML parse failures.",
        "Equal rendered manifests may pass for one input and fail for another; cached manifests still undergo the input-aware assertion.",
        "",
        "**Depth:** vary nested conditions around one resource, keeping two quantile selector fields.",
        "**Redundancy:** vary unused fields with no nested conditions; every unused Boolean doubles equivalent-input multiplicity.",
        "**Clustering:** keep the chart fixed with two quantile selectors and no nested conditions, and vary failure placement.",
        "Clustering zero orders assignments uniformly at random; one orders them by the number of switches differing from a seeded centre.",
        "Intermediate controls blend random priority with this distance. They are placement controls, not "
        "measured correlation coefficients.",
        "The ledger records the fraction of single-switch neighbours of failing inputs that also fail.",
        "",
        "Error counts round down to whole assignments. Higher rates add failures to the same seeded ordering; actual rates are recorded.",
        "The oracle is independent of selection: a failure enters the scheduler only after its input is evaluated.",
        "",
        f"Fixed settings: {metadata['input_fields']} Boolean fields, strength {metadata['permutations']}, {metadata['workers']} worker, "
        f"{metadata['repeats']} paired seeds, and {metadata['time_limit_seconds']} seconds per method's execution.",
        "Small domains are fully enumerated before filtering. Each method starts with fresh compiler and "
        "render caches; OS caches can be warm.",
        "Method order is shuffled within every paired comparison. Total time includes planning and execution; "
        "chart generation is excluded.",
        "`filter` and `filter-aggressive` expand failed symbolic regions. The other methods retain their "
        "usual expansion-disabled behavior.",
        "`sample-random` uses 70% with its 128-case floor. Aggressive sampling falls back when calibration "
        "cannot support it; the CSV records why.",
        "",
        "Colours share a scale across methods within each figure. Cells show means across completed paired runs.",
        "T = an incomplete execution; N/A = no erroneous inputs; blank = no measurement. No partial timing is "
        "shown as a completed runtime.",
        "The CSV includes observed ranges, not confidence intervals. These synthetic assertions do not "
        "establish recall for arbitrary charts.",
        "",
        "[Individual measurements](results.csv) · [Means and ranges](summary.csv) · [Oracle populations and provenance](results.json)",
        "",
    ]
    summary: list[dict[str, object]] = []
    for axis, raw_values in mapping(metadata["axes"]).items():
        values = [float(str(value)) for value in sequence(raw_values)]
        selected = [row for row in rows if row["axis"] == axis]
        for metric in METRICS:
            numeric = [float(str(row[metric])) for row in selected if row[metric] is not None and row["status"] == "passed"]
            maximum = 1.0 if metric == "error_recall" else max(numeric, default=1.0) or 1.0
            columns = min(4, len(methods))
            figure, axes = plt.subplots(
                math.ceil(len(methods) / columns), columns, figsize=(5 * columns, 3.8 * math.ceil(len(methods) / columns)), squeeze=False
            )
            for panel, method in zip(axes.flat, methods, strict=False):
                matrix = np.full((len(values), len(rates)), np.nan)
                annotations: dict[tuple[int, int], str] = {}
                for y, value in enumerate(values):
                    for x, rate in enumerate(rates):
                        batch = [
                            row
                            for row in selected
                            if row["strategy"] == method and row["axis_value"] == value and row["error_percent"] == rate
                        ]
                        if not batch:
                            continue
                        complete = len(batch) == int(str(metadata["repeats"])) and all(row["status"] == "passed" for row in batch)
                        observations = [float(str(row[metric])) for row in batch if row[metric] is not None]
                        if not complete:
                            annotations[y, x] = "T" if any(row["status"] != "passed" for row in batch) else "partial"
                        elif observations:
                            matrix[y, x] = statistics.mean(observations)
                            annotations[y, x] = f"{matrix[y, x]:.2g}"
                        else:
                            annotations[y, x] = "N/A"
                        summary.append(
                            {
                                "axis": axis,
                                "axis_value": value,
                                "error_percent": rate,
                                "strategy": method,
                                "metric": metric,
                                "paired_runs": len(batch),
                                "complete": complete,
                                "mean": statistics.mean(observations) if complete and observations else None,
                                "minimum": min(observations) if complete and observations else None,
                                "maximum": max(observations) if complete and observations else None,
                            }
                        )
                panel.imshow(matrix, aspect="auto", origin="lower", vmin=0, vmax=maximum, cmap="viridis")
                panel.set_facecolor("#e2e8f0")
                for (y, x), annotation in annotations.items():
                    color = "white" if not np.isnan(matrix[y, x]) and matrix[y, x] < maximum * 0.55 else "#0f172a"
                    panel.text(x, y, annotation, ha="center", va="center", fontsize=8, color=color)
                panel.set_xticks(range(len(rates)), [f"{rate:g}" for rate in rates])
                panel.set_yticks(range(len(values)), [f"{value:g}" for value in values])
                panel.set(title=method, xlabel="Requested erroneous inputs (%)", ylabel=labels[axis])
            for panel in list(axes.flat)[len(methods) :]:
                panel.set_visible(False)
            figure.suptitle(f"{metric_labels[metric]} vs error rate and {axis}")
            name = f"{axis}-{metric.replace('_', '-')}"
            finish(
                figure,
                output,
                name,
                "Paired means; shared colour scale. T = incomplete; N/A = zero errors. See CSV for actual rates and ranges.",
            )
            lines.extend([f"![{metric_labels[metric]} by {axis}]({name}.png)", ""])
    with (output / "summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]) if summary else ["axis"], lineterminator="\n")
        writer.writeheader()
        writer.writerows(summary)
    (output / "README.md").write_text("\n".join(lines))
